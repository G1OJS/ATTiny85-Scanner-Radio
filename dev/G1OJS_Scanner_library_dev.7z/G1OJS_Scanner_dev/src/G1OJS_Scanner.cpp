
#include <G1OJS_Scanner.h>
#include <G1OJS_Tiny_Si5351_CLK0.h>
#include <SSD1306Ascii.h>
#include <SSD1306AsciiWire.h>


#define OLED_I2C_ADDRESS 0x3C

char AudioInputPin;
char SquelchOutputPin;
char AGCOutputPin;


preSquelchAudioMonitorStructure preSquelchAudioMonitor;
AGCStructure AGC;
ScannerDisplayStructure ScannerDisplay;
SquelchStructure Squelch;
ScannerStructure Scanner;
i2cStructure i2c;

SSD1306AsciiWire SSD1306;
G1OJS_Tiny_Si5351_CLK0 DDS;

//==================
// proxy for millis()
//==================
// AGC output ideally needs fast PWM. If this affects millis()
// use the appropriate divider here:
unsigned long ms(){ return  millis()/8; }


// =================
// I2C comms initialiser that waits until initialised
//==================

  void i2cStructure::init(){
    Wire.begin();
      do{
        Wire.beginTransmission(OLED_I2C_ADDRESS);  // Known I2C address (e.g., OLED)
        delay(10);
      } while (Wire.endTransmission() != 0);
  };

// =================
// ScannerDisplay
//==================
  
  void ScannerDisplayStructure::init(){
    SSD1306.begin(&Adafruit128x64, OLED_I2C_ADDRESS);
    SSD1306.clear();
    SSD1306.setFont(Arial14);
    SSD1306.set2X();
    SSD1306.clear();
    SSD1306.println("G1OJS");
    SSD1306.println("ATTiny85");
    delay(500);
    SSD1306.clear();
    SSD1306.println("Airband");
    SSD1306.println("Scanner");
    delay(500);
    SSD1306.clear();
  }

  void ScannerDisplayStructure::showStatusChar(char* symbol){
    SSD1306.setCursor(100,0);
    SSD1306.print(symbol);
  }

  void ScannerDisplayStructure::showChannel(byte channel) 
    {
    SSD1306.setCursor(0, 0);
    ultoa((unsigned long)channel, buf, 10);
    SSD1306.print(buf);
  }

  void ScannerDisplayStructure::showFreq(unsigned long freq_Hz) 
    {
    SSD1306.setCursor(0, 4);
    ultoa(freq_Hz/1000, buf, 10);
    SSD1306.print(buf);
  }


// =================
// AUDIO MONITOR
//==================


  void preSquelchAudioMonitorStructure::init(char InputPin){
    analogReference(DEFAULT); 
    AudioInputPin = InputPin;
    pinMode(AudioInputPin, INPUT);
    currentAmplitude=0;
  }

  void preSquelchAudioMonitorStructure::updateCurrentAmplitude(){
    int currSigLevel=analogRead(AudioInputPin); 
    currentAmplitude=abs(currSigLevel-lastSigLevel);
    lastSigLevel=currSigLevel;
  }

    
  
// =================
// SQUELCH
//==================

  void SquelchStructure::init(char OutputPin) {
    SquelchOutputPin = OutputPin;
    pinMode(SquelchOutputPin, OUTPUT);
    close();
  }
  
  void SquelchStructure::setThreshold(byte squelch_threshold) {
    threshold=squelch_threshold;
  } 

  void SquelchStructure::open() {
    status = OPEN;
    digitalWrite(SquelchOutputPin, LOW);
  }

  void SquelchStructure::close() {
    status = CLOSED;
    digitalWrite(SquelchOutputPin, HIGH);
  }

  void SquelchStructure::implement() {
    if (preSquelchAudioMonitor.currentAmplitude > threshold) {
      if (status == CLOSED) {
        open();
      }
      lastAboveThreshold_ms = ms();
    } else {
      if ((ms() - lastAboveThreshold_ms) > tail_ms) {
        close();
      }
    }
  }

// =================
// MEMORIES
//==================



// =================
// SCANNER
//==================

  void ScannerStructure::init(){
    channel = 0;
    mode = SCAN;
  }

  void ScannerStructure::spinnerNext() {
    const char spinner[] = {'|', '/', '-', '\\'};
    ScannerDisplay.showStatusChar(spinner[channel++ % 4]);
    }

  void ScannerStructure::setTestFreq(){
    setRxFreq(128602650UL);
    ScannerDisplay.showChannel(0);
    ScannerDisplay.showFreq(128602650UL); 
  }



  void ScannerStructure::findNextBusyMemory(){
    if (Squelch.status == Squelch.OPEN) return;
 //   do{channel = (channel + 1) % nChannels;} while (is_locked_out(channel));

    ScannerDisplay.showChannel(channel);
    if(channels_Hz[channel] != lastFreq) {
      setRxFreq(channels_Hz[channel]);
      ScannerDisplay.showFreq(channels_Hz[channel]); 
      lastFreq = channels_Hz[channel];
    }
  }

  void ScannerStructure::doChannelSurvey(){
    
	
	for (int iPass=0; iPass<10; iPass++){
		for (int iCh25=0; iCh25<720; iCh25++){
		  setRxFreq(118000000UL + 25000*(uint32_t)iCh25);
		  for (int iDwell=0;iDwell<10;iDwell++){
		    preSquelchAudioMonitor.updateCurrentAmplitude();
			delay(1);
		  }
		  if(levelsMin_ch25[iCh25]>preSquelchAudioMonitor.currentAmplitude) levelsMin_ch25[iCh25] = preSquelchAudioMonitor.currentAmplitude;
		  if(levelsMax_ch25[iCh25]<preSquelchAudioMonitor.currentAmplitude) levelsMax_ch25[iCh25] = preSquelchAudioMonitor.currentAmplitude;
		}

	for (int iCh25=0; iCh25<720; iCh25++){
       Serial.println(118000000UL + 25000*(uint32_t)iCh25);
	   Serial.print(" ");
	   Serial.print(levelsMin_ch25[iCh25]);
	   Serial.print(" ");
	   Serial.print(levelsMax_ch25[iCh25]);	
	   Serial.println();
	}
	}

  }

  void ScannerStructure::startSearch(){
    searchFreq = 118000000ULL;
    mode = SEARCH;
  }

  void ScannerStructure::setRxFreq(unsigned long freq_Hz){
    #define IF_kHz 10707
    DDS.set_freq_Hz((uint32_t)freq_Hz + (uint32_t)IF_kHz*1000);
  }

  void ScannerStructure::scan(){
    if (mode == SCAN) {findNextBusyMemory();}
   // if (mode == SEARCH) {findNextBusyFrequency();}
  }

// =================
// AGC
//==================

  void AGCStructure::init(){
     AGC.AGCLevel= minOutputLevel;
  }

  void AGCStructure::updateAGCLevel(){
    int currAmp=preSquelchAudioMonitor.currentAmplitude;
    if (currAmp > thresholdUpper) {AGCLevel += 2*(AGCLevel < maxOutputLevel);}
    if (currAmp < thresholdLower) {AGCLevel -= 1*(AGCLevel > minOutputLevel);}
  }

