// MIT License
//
// Copyright (c) 2025 Alan Robinson G1OJS
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
//

#ifndef G1OJS_Scanner_H_
#define G1OJS_Scanner_H_

#include "Arduino.h"
#include "Wire.h"

#define G1OJS_Scanner_VERSION "1.0.0"


// =================
// proxy for ms() as timer0 will be running at 4kHz not 500Hz
//==================
unsigned long ms();

// =================
// I2C comms initialiser that waits until initialised
//==================
struct i2cStructure{
  void init();
};

// =================
// ScannerDisplay
//==================
struct ScannerDisplayStructure {
  void init();
  void showChannel(byte channel);
  void showFreq(unsigned long freq_Hz);
  void showStatusChar(char* symbol);
  private:
    char buf[8];
};

// =================
// AUDIO MONITOR
//==================
struct preSquelchAudioMonitorStructure {
  int currentAmplitude=0;
  void init(char InputPin);
  void updateCurrentAmplitude();
  private:
    int lastSigLevel=0;
};

// =================
// SQUELCH
//==================
struct SquelchStructure {
  enum statusValues {OPEN=0, CLOSED=1};
  statusValues status = CLOSED;

  void init(char OutputPin);
  void open();
  void close();
  void implement();
  void setThreshold(byte squelch_threshold);
  private:
    int tail_ms   = 1000;
    int threshold = 12;
    unsigned long lastAboveThreshold_ms;

} ;


// =================
// SCANNER
//==================
struct ScannerStructure{
  #define channelStep 25000
  #define nChannels 10
  #define nLockouts 1
  unsigned long channels_Hz[nChannels]= {128602650, 127825000, 132846700, 135050000, 129425000};
  byte levelsMin_ch25[720]={255};
  byte levelsMax_ch25[720]={0};
  boolean lockout[nLockouts];
  int channel;
  enum scannermodes{SCAN, SEARCH};
  scannermodes mode;

  void init();
  void spinnerNext();
  void setTestFreq();
  void setRxFreq(unsigned long freq_Hz);
  void findNextBusyMemory();
//  void findNextBusyFrequency();
  void doChannelSurvey();
  void startSearch();
  void scan();

  private:
    unsigned long lastFreq=0;
    unsigned long searchFreq;

} ;

// =================
// AGC
//==================
struct AGCStructure{
  unsigned int AGCLevel;
  void init();
  void updateAGCLevel();

  private:
    const byte thresholdUpper = 160;
    const byte thresholdLower = 20;
    const byte maxOutputLevel = 250;
    const byte minOutputLevel = 110;
    byte level = minOutputLevel;
};

extern preSquelchAudioMonitorStructure preSquelchAudioMonitor;
extern AGCStructure AGC;
extern ScannerDisplayStructure ScannerDisplay;
extern SquelchStructure Squelch;
extern ScannerStructure Scanner;
extern i2cStructure i2c;


#endif

